import * as Tone from 'tone'
import {createRoot} from 'react-dom/client'

const synth = new Tone.Synth().toDestination();

let notes = ['c4', 'd4', 'e4', 'f4', 'g4', 'a4', 'b4', 'c5']

let notesKeys = {
    'a': 'c4', 's': 'd4', 'd': 'e4', 'f': 'f4',
    'g': 'g4', 'h': 'a4', 'j': 'b4', 'k': 'c5'
}

notes.forEach(note => document.getElementById(note)
    .addEventListener('click', () => synth.triggerAttackRelease(note, "8n"))
)

function noteSound(event) {
    synth.triggerAttackRelease(notesKeys[event.key.toLowerCase()], '8n')
}

document.getElementById('body').addEventListener('keypress', noteSound)


//Componente react
function PianoKeys(){
    return <button onClick={ () => synth.triggerAttackRelease("c4", "8n")} id="c4">c4</button>
}

const root = creatRoot(document.getElementById('root'))//linea necesaria para una aplicacion  de react
root.render(<PianoKeys/>)//jsx